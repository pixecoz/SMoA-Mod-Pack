const hyperPhase = extendContent (GenericCrafter,"hyper-phase-weaver",{});
hyperPhase.drawer = new DrawRotator();
